<?php
// class tmdt
// {
//     private $con;

//     public function connect() {
//         // Kết nối cơ sở dữ liệu bằng mysqli
//         $this->con = new mysqli("localhost", "usertmdt", "passtmdt", "qlbenhvien");

//         // Kiểm tra lỗi kết nối
//         if ($this->con->connect_error) {
//             die("Không Kết Nối Được: " . $this->con->connect_error);
//         }

//         // Thiết lập mã hóa UTF-8
//         $this->con->set_charset("utf8");

//         return $this->con;
//     }
// }
?>
