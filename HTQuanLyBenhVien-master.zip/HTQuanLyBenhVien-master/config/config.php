<?php 
    //connect database
    $conn = mysqli_connect("localhost","quanlibenhvien","1234","qlbenhvien");
    if(!$conn){
       echo 'Không kết nối được CSDL';
    }

/**
 * Mở kết nối đến CSDL sử dụng PDO
 */

?>