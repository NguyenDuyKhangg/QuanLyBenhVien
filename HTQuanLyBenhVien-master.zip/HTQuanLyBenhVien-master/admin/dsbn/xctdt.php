
<div class="container mt-5">
        <h2 class="text-center mb-4">Chi Tiết Đơn Thuốc</h2>
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Thông Tin Đơn Thuốc</h5>
            </div>
            <div class="card-body">
                <p><strong>Tên Bệnh Nhân:</strong> Nguyễn Văn A</p>
                <p><strong>Mã Khám Bệnh:</strong> KB123456</p>
                <p><strong>Mã Đơn Thuốc:</strong> ĐT7890</p>
                <p><strong>Trạng Thái Đơn Thuốc:</strong> Đã hoàn thành</p>
                <p><strong>Ngày Lập Đơn:</strong> 2024-10-30</p>
                <p><strong>Ghi Chú:</strong> Bệnh nhân cần theo dõi định kỳ.</p>
                <a href="?quanli=don-thuoc" class="btn btn-primary">Quay lại danh sách</a>
            </div>
        </div>
    </div>

