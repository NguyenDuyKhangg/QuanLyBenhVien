<div class="hoaDonThanhToan">
    <div class="detailThanhToan">
        <div class="container" style="width: 800px;">
            <div class="row">
                <div class="col-lg-12 p-4">
                    <div class="bg-light rounded h-100 p-5 text-center">
                        <h3 style="text-align: center; color: #009CFF; padding: 20px;">
                            <i class="fa-solid fa-circle-check" style="color: #63E6BE;"></i>
                            Thanh toán thành công!
                        </h3>
                        <a href="index.php?quanli=thanh-toan" class="btn btn-info mt-3">Quay về</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>