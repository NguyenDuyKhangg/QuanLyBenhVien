
<script src="public/js/jquery-3.7.1.min.js"></script>
<script src="public/js/bootstrap.bundle.min.js"></script>